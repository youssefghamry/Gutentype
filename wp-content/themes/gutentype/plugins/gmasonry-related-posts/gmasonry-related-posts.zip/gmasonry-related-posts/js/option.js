jQuery(document).ready(function($){
	$('.widget_gridmasonryrelatedpo_widget').masonry({});
});
